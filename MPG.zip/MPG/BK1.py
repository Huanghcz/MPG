import time

import numpy as np
from matplotlib import pyplot as plt
from scipy.optimize import minimize


def f1(x):
    return x[0]**2 + x[1]**2

def grad_f1(x):
    return np.array([2*x[0], 2 * x[1]])

def f2(x):
    return (x[0] - 5)**2 + (x[1] - 5)**2

def grad_f2(x):
    return np.array([2*x[0] - 10, 2*x[1] - 10])


def grad(x):
    return np.array([grad_f1(x), grad_f2(x)])


def g1(x):
    return 0


def g2(x):
    return 0


def f(x):
    return np.array([f1(x), f2(x)])


def g(x):
    return np.array([g1(x), g2(x)])


def F(x):
    return np.array([f1(x) + g1(x), f2(x) + g2(x)])


def phi(u, x):
    term1 = np.dot(grad_f1(x), (u - x)) + g1(u) - g1(x)
    term2 = np.dot(grad_f2(x), (u - x)) + g2(u) - g2(x)
    return max(term1, term2)


def max_grad(x, d):
    term1 = np.dot(grad_f1(x), d)
    term2 = np.dot(grad_f2(x), d)
    return 0 if term1 > term2 else 1




def main(x, alpha, gamma, tau1, tau2):
    start_time = time.time()  # 记录开始时间
    x0 = x.copy()
    k = 0
    while True:
        # step1
        def objective(u, x, alpha):
            psi_x = np.sum(u ** 2)
            penalty = (1 / (2 * alpha)) * np.sum((u - x) ** 2)
            return psi_x + penalty

        def p_alpha(x, alpha):
            u0 = x
            result = minimize(objective, u0, args=(x, alpha), method='BFGS')
            return result.x

        p_alpha = p_alpha(x, alpha)
        theta_alpha = phi(p_alpha, x0) + (np.linalg.norm(p_alpha - x0) ** 2) / (2 * alpha)

        # step2
        if abs(theta_alpha) < 1e-4:
            break

        found_tk = False
        while not found_tk:
            d = p_alpha - x0
            jk = max_grad(x0, d)
            t_trial = 1

            while True:
                # step3.1
                term1 = f(x0 + t_trial * d)[jk]
                term2 = f(x0)[jk] + t_trial * np.dot(grad(x0)[jk], d) + t_trial * gamma * (np.linalg.norm(d,ord = 2) ** 2) / 2

                if term1 <= term2:
                    break
                else:
                    ff = f(x0 + t_trial * d)[jk]
                    f0 = f(x0)[jk]
                    g0 = np.dot(grad(x0)[jk],d)
                    t_min = 1e-15
                    if t_trial < t_min:
                        break
                    else:
                        if g0 < 0:
                            t_new = ( (g0 / ( (f0-ff) / t_trial + g0 ) ) / 2 ) * t_trial
                            if t_new > t_trial * tau1 and t_new < t_trial * tau2:
                                t_trial = t_new
                            else:
                                t_trial /= 2
                        else:
                            t_trial /= 2


            #step3.2
            if np.all(F(x0 + t_trial * d) <= F(x0)):
                tk = t_trial
                break

            while True:
                # step3.3
                ff = f(x0 + t_trial * d)[jk]
                f0 = f(x0)[jk]
                g0 = np.dot(grad(x0)[jk], d)
                t_min = 1e-15
                if t_trial < t_min:
                    break
                else:
                    if g0 < 0:
                        t_new = ((g0 / ((f0 - ff) / t_trial + g0)) / 2) * t_trial
                        if t_new > t_trial * tau1 and t_new < t_trial * tau2:
                            t_trial = t_new
                        else:
                            t_trial /= 2
                    else:
                        t_trial /= 2

                term11 = F(x0 + t_trial * d)[0]
                term12 = F(x0)[0] + t_trial * np.dot(grad(x0)[0], d) + t_trial * gamma * (np.linalg.norm(d) ** 2) / 2
                term21 = F(x0 + t_trial * d)[1]
                term22 = F(x0)[1] + t_trial * np.dot(grad(x0)[1], d) + t_trial * gamma * (np.linalg.norm(d) ** 2) / 2

                if term11 <= term12 and term21 <= term22:
                    tk = t_trial
                    found_tk = True
                    break

        #step4
        x0 = x0 + tk * d
        k += 1

    end_time = time.time()  # 记录结束时间
    elapsed_time = end_time - start_time  # 计算程序运行时间
    return x0, k, elapsed_time


# Parameters
alpha = 1
gamma = 1.999999
tau1 = 0.05
tau2 = 0.95


# 撒点
np.random.seed(0)
solution_points = np.random.uniform(-5, 10, (200, 2))

# save the optimal
f11_values = []
f22_values = []

# save the initial
f11_initial_values = []
f22_initial_values = []
point_set = []
total_time = 0
iter_num = 0
num = 0
for point in solution_points:
    optimized_result,k, times = main(point, alpha, gamma, tau1, tau2)
    f110 = f1(point)
    f220 = f2(point)
    f111 = f1(optimized_result)
    f221 = f2(optimized_result)
    f11_values.append(f111)
    f22_values.append(f221)
    total_time += times
    iter_num += k
    num += 1
    print(f'第{num}个点')
    print(
        f'点为{point},优化后为{optimized_result},f11函数初始值为{f110},优化后为{f111};f22函数初始值为{f220},优化后为{f221}')
print(f'总耗费时间{total_time}')
print(f'总迭代次数{iter_num}')
# # 保存数据点
# solution_df = pd.DataFrame(point_set, columns=['X1', 'X2'])
# solution_df.to_excel('iteration_results5.xlsx', index=False)
def is_pareto_efficient(costs):
    is_efficient = np.ones(costs.shape[0], dtype=bool)
    for i, c in enumerate(costs):
        if is_efficient[i]:
            is_efficient[is_efficient] = np.any(costs[is_efficient] < c, axis=1)
            is_efficient[i] = True
    return is_efficient
costs = np.column_stack((f11_values, f22_values))
pareto_mask = is_pareto_efficient(costs)
pareto_points = costs[pareto_mask]
# 绘制结果
plt.figure(figsize=(10, 6))
# plt.scatter(f11_initial_values, f22_initial_values, c='blue', marker='x', label='Initial Points')
plt.scatter(pareto_points[:, 0], pareto_points[:, 1], c='red', marker='o')
plt.scatter(f11_values, f22_values, c='blue', marker='x')
plt.legend()
plt.savefig("BK1.png")
plt.show()
