import numpy as np
from scipy.optimize import minimize
import time


def evalg(n, x, i):
    # Replace this with the actual evaluation function
    pass


def evalh(n, x, i, A, b):
    # Replace this with the actual evaluation function
    pass


def evalgradg(n, x, i):
    # Replace this with the actual gradient evaluation function
    pass


def subproblemProxGrad(n, m, l, u, x, alpha, JG, H, dimA, A, b):
    # Replace this with the actual subproblem solver function
    pass


def armijo(n, m, x, d, F, JG, tau, A, b):
    # Replace this with the actual Armijo line search function
    pass


def implicitLS(n, m, l, u, x, p, alpha, G, JG, H, dimA, A, b):
    # Replace this with the actual implicit LS function
    pass


def ProxGrad(n, m, l, u, x, lsopt, dimA, A, b):
    start_time = time.time()
    tol = 1e-4
    itermax = 200

    # Counters
    ngev = 0
    nhev = 0
    iter = 0

    # Evaluate F
    G = np.zeros(m)
    H = np.zeros(m)
    for i in range(m):
        G[i] = evalg(n, x, i)
        ngev += 1
        H[i], flag = evalh(n, x, i, A, b)
        nhev += 1

        if flag != 0:
            print('\nAn error occurred while evaluating H.')
            print(f'Number of G_i evaluations: {ngev}')
            print(f'Number of H_i evaluations: {nhev}')
            print(f'CPU time(s): {time.time() - start_time:.1f}')
            return None, -1, iter, ngev, nhev

    F = G + H

    print('----------------------------------------------------------------------')
    print('   Proximal Gradient Method for Composite Multiobjective Optimization')
    print('----------------------------------------------------------------------')
    print(f'Number of variables: {n}')
    print(f'Number of objectives: {m}')
    print(f'Optimality tolerance: {tol:.0e}')
    print(f'Line search scheme: {lsopt}\n')

    while True:
        # Compute the Jacobian of G
        JG = np.zeros((m, n))
        for i in range(m):
            JG[i, :] = evalgradg(n, x, i)

        # Solve the subproblem
        alpha = 1
        theta, tau, p, flagIS = subproblemProxGrad(n, m, l, u, x, alpha, JG, H, dimA, A, b)

        if flagIS != 0:
            print('\nAn error occurred while solving the subproblem H.')
            print(f'Number of G_i evaluations: {ngev}')
            print(f'Number of H_i evaluations: {nhev}')
            print(f'CPU time(s): {time.time() - start_time:.1f}')
            return None, -1, iter, ngev, nhev

        # Print information
        if iter % 10 == 0:
            print('\n{:5s} {:8s} {:8s} {:8s} {:8s} {:8s}'.format('it', '|theta|', 'fun1', 'fun2', 'IS', 'LS'))

        if iter == 0:
            print(f'{iter:5d} {abs(theta):8.2e} {F[0]:+8.2e} {F[1]:+8.2e} {flagIS:<8} -')
        else:
            print(f'{iter:5d} {abs(theta):8.2e} {F[0]:+8.2e} {F[1]:+8.2e} {flagIS:<8} {flagLS:<8}')

        # Stopping criteria
        if abs(theta) <= tol:
            print('\nSolution was found.')
            print(f'Number of G_i evaluations: {ngev}')
            print(f'Number of H_i evaluations: {nhev}')
            print(f'CPU time(s): {time.time() - start_time:.1f}')
            return x, 0, iter, ngev, nhev

        if iter >= itermax:
            print('\nThe number of maximum iterations was reached.')
            print(f'CPU time(s): {time.time() - start_time:.1f}')
            return x, 1, iter, ngev, nhev

        # Iterate
        iter += 1

        if lsopt in [1, 2]:
            d = p - x

        if lsopt == 1:
            stp = 1
            DG0 = JG @ d
            imax = np.argmax(DG0)
            stp, Gtrialimax, ngevLS, flagLS = explicitLSone(n, x, d, stp, imax, G[imax], DG0[imax])
            ngev += ngevLS
            xtrial = x + stp * d
            Gtrial = np.zeros(m)
            Htrial = np.zeros(m)
            Gtrial[imax] = Gtrialimax
            Ftrial = np.zeros(m)
            Fdec = True

            for i in range(m):
                if i == imax:
                    continue
                Gtrial[i] = evalg(n, xtrial, i)
                ngev += 1
                Htrial[i], flag = evalh(n, xtrial, i, A, b)
                nhev += 1

                if flag != 0:
                    print('\nAn error occurred while evaluating H.')
                    print(f'Number of G_i evaluations: {ngev}')
                    print(f'Number of H_i evaluations: {nhev}')
                    print(f'CPU time(s): {time.time() - start_time:.1f}')
                    return None, -1, iter, ngev, nhev

                Ftrial[i] = Gtrial[i] + Htrial[i]
                if Ftrial[i] > F[i]:
                    Fdec = False
                    break

            if Fdec:
                Htrial[imax], flag = evalh(n, xtrial, imax, A, b)
                nhev += 1

                if flag != 0:
                    print('\nAn error occurred while evaluating H.')
                    print(f'Number of G_i evaluations: {ngev}')
                    print(f'Number of H_i evaluations: {nhev}')
                    print(f'CPU time(s): {time.time() - start_time:.1f}')
                    return None, -1, iter, ngev, nhev

                Ftrial[imax] = Gtrial[imax] + Htrial[imax]
                x = xtrial
                G = Gtrial
                H = Htrial
                F = Ftrial
            else:
                stp, G, ngevLS, flagLS = explicitLS(n, m, x, d, stp, ifirst, G, DG0, DG0)
                ngev += ngevLS

                if flagLS == -1:
                    print('\nAn error occurred in the line search procedure.')
                    print(f'Number of G_i evaluations: {ngev}')
                    print(f'Number of H_i evaluations: {nhev}')
                    print(f'CPU time(s): {time.time() - start_time:.1f}')
                    return None, -1, iter, ngev, nhev

                x = x + stp * d
                for i in range(m):
                    H[i], flag = evalh(n, x, i, A, b)
                    nhev += 1

                    if flag != 0:
                        print('\nAn error occurred while evaluating H.')
                        print(f'Number of G_i evaluations: {ngev}')
                        print(f'Number of H_i evaluations: {nhev}')
                        print(f'CPU time(s): {time.time() - start_time:.1f}')
                        return None, -1, iter, ngev, nhev

                F = G + H

        if lsopt == 2:
            stp, G, H, ngevLS, nhevLS, flagLS = armijo(n, m, x, d, F, JG, tau, A, b)
            ngev += ngevLS
            nhev += nhevLS

            if flagLS == -1:
                print('\nAn error occurred in the line search procedure.')
                print(f'Number of G_i evaluations: {ngev}')
                print(f'Number of H_i evaluations: {nhev}')
                print(f'CPU time(s): {time.time() - start_time:.1f}')
                return None, -1, iter, ngev, nhev

            x = x + stp * d
            F = G + H

        if lsopt == 3:
            p, G, ngevLS, flagLS = implicitLS(n, m, l, u, x, p, alpha, G, JG, H, dimA, A, b)
            ngev += ngevLS

            if flagLS == -1:
                print('\nAn error occurred in the line search procedure.')
                print(f'Number of G_i evaluations: {ngev}')
                print(f'Number of H_i evaluations: {nhev}')
                print(f'CPU time(s): {time.time() - start_time:.1f}')
                return None, -1, iter, ngev, nhev

            x = p
            for i in range(m):
                H[i], flag = evalh(n, x, i, A, b)
                nhev += 1

                if flag != 0:
                    print('\nAn error occurred while evaluating H.')
                    print(f'Number of G_i evaluations: {ngev}')
                    print(f'Number of H_i evaluations: {nhev}')
                    print(f'CPU time(s): {time.time() - start_time:.1f}')
                    return None, -1, iter, ngev, nhev

            F = G + H
